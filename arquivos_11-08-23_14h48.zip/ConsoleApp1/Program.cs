﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pratica1
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            Pilha calculadora = new Pilha(100);
            int num1=0, num2=0;
            int soma = 0;
            string x = "";
            
            Console.WriteLine("Insira um número ou uma operação.\nS- para sair.");
            

            while (x !="S"|| x != "s")
            {
                x = Console.ReadLine();
                switch (x)
                {
                    case "+":
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                           num1= calculadora.Desempilhar(); 
                        }
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                            num2 = calculadora.Desempilhar();
                        }
                        soma = num1 + num2;
                        
                        calculadora.Empilhar(soma);
                        Console.WriteLine(num1 + "+"+ num2 + ":" + soma);
                        break;
                    case "-":
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                           num1 =  calculadora.Desempilhar();
                        }
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                           num2 =  calculadora.Desempilhar();
                        }
                        int sub = num1 - num2;
                        calculadora.Empilhar(sub);
                        Console.WriteLine(num1 + "-" + num2 + ":" + sub);
                        break;
                    case "*":
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                            num1 = calculadora.Desempilhar();
                        }
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                            num2 = calculadora.Desempilhar();
                        }
                        int mult = num1 * num2;
                        Console.WriteLine(num1 + "*" + num2 + ":" + mult);
                        break;
                    case "/":
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                            num1 = calculadora.Desempilhar();
                        }
                        if (calculadora.Vazia())
                        {
                            Erro();
                            break;
                        }
                        else
                        {
                            num2 = calculadora.Desempilhar();
                        }
                        int div = num1 / num2;
                        Console.WriteLine(num1 + "/" + num2 + ":" + div);
                        break;
                    default:
                        calculadora.Empilhar(int.Parse(x));
                        break;
                }
            }
        }
        public static void Erro()
        {
            Console.WriteLine("Erro na operação. ");
        }
    }
}


